const app = require('./src/app');
const config = require('./src/config');

const server = app.listen(config.port, config.host, () => {
  console.log(`Server running on ${config.host}:${config.port} in ${config.env} mode`);
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`Port ${config.port} already in use.`);
  } else {
    console.error('Server failed to start:', err.message);
  }
  process.exit(1);
});

const gracefulShutdown = () => {
  console.log('Shutting down gracefully...');
  server.close(() => process.exit(0));
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);